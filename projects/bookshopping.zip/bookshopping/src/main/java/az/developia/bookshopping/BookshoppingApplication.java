package az.developia.bookshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookshoppingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookshoppingApplication.class, args);
	}

}
